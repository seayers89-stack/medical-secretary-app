Veyn Task Tracker — desktop app
================================

This is a small offline task timer: time what you're working on, set an
optional time budget per task, and see where your day goes by tag.

All your data stays on THIS computer, in this browser — nothing is sent
to Veyn or stored on Veyn's servers.

HOW TO SET IT UP
-----------------
1. Unzip this folder anywhere on your PC (e.g. Desktop or Documents).
2. Open "index.html" in Microsoft Edge.
3. Click the "..." menu (top right) > Apps > "Install this site as an app"
   (or click the install icon that appears in the address bar).
4. It now has its own window and Start Menu entry — right-click its
   taskbar icon and choose "Pin to taskbar" for one-click access.

Your tasks are saved automatically as you use it. Because the data lives
in the browser profile on this PC, it won't appear on another computer,
and won't sync anywhere — it's just yours.
